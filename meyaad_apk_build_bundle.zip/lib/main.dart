import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/clinic_location_screen.dart';
import 'screens/doctor_dashboard_screen.dart';

void main() {
  runApp(const MeyaadApp());
}

const brand = Color(0xFF087F8C);
const navy = Color(0xFF173B52);
const pageBg = Color(0xFFF4F8FA);

class MeyaadApp extends StatelessWidget {
  const MeyaadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ميعاد',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brand, primary: brand),
        scaffoldBackgroundColor: pageBg,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: navy,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFFE3ECEF)),
          ),
        ),
      ),
      home: const PatientHomeScreen(),
    );
  }
}

class PatientHomeScreen extends StatefulWidget {
  const PatientHomeScreen({super.key});

  @override
  State<PatientHomeScreen> createState() => _PatientHomeScreenState();
}

class _PatientHomeScreenState extends State<PatientHomeScreen> {
  int tab = 0;
  String specialty = 'الكل';

  final doctors = const [
    DoctorDemo(name: 'د. علي حسن', specialty: 'طب عام', clinic: 'عيادة النور', area: 'الناصرية - شارع الحبوبي', fee: '١٥٬٠٠٠ د.ع', time: 'اليوم، ٥:٣٠ م', lat: 31.0575, lng: 46.2573),
    DoctorDemo(name: 'د. زهراء كريم', specialty: 'أطفال', clinic: 'عيادة الرحمة', area: 'الناصرية - صوب الشامية', fee: '٢٠٬٠٠٠ د.ع', time: 'اليوم، ٦:٠٠ م', lat: 31.0458, lng: 46.2591),
    DoctorDemo(name: 'د. مصطفى جاسم', specialty: 'أسنان', clinic: 'مركز الابتسامة', area: 'الناصرية - شارع النيل', fee: '٢٥٬٠٠٠ د.ع', time: 'غداً، ٤:٠٠ م', lat: 31.0521, lng: 46.2654),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      const _InfoPage(icon: Icons.confirmation_number_outlined, title: 'حجوزاتي', text: 'بعد ربط قاعدة البيانات، ستظهر هنا حجوزاتك وأرقام أدوارك الحقيقية.'),
      const _InfoPage(icon: Icons.person_outline_rounded, title: 'حسابي', text: 'ملف المريض وتسجيل الدخول برقم الهاتف سيُفعّلان بعد إعداد خدمة المصادقة.'),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(children: [
            Icon(Icons.calendar_month_rounded, color: brand, size: 28),
            SizedBox(width: 8),
            Text('ميعاد', style: TextStyle(fontWeight: FontWeight.w900)),
          ]),
          actions: [
            IconButton(onPressed: () => _toast('الإشعارات ستُربط لاحقاً'), icon: const Icon(Icons.notifications_none_rounded)),
          ],
        ),
        body: SafeArea(child: IndexedStack(index: tab, children: pages)),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.confirmation_number_outlined), selectedIcon: Icon(Icons.confirmation_number), label: 'حجوزاتي'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _home() {
    final filtered = specialty == 'الكل' ? doctors : doctors.where((d) => d.specialty == specialty).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(colors: [brand, Color(0xFF075D70)], begin: Alignment.topRight, end: Alignment.bottomLeft),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('صحتك ووقتك يهمّنا', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
            SizedBox(height: 8),
            Text('احجز موعدك وتابع دورك من موبايلك', style: TextStyle(color: Colors.white, fontSize: 14)),
            SizedBox(height: 16),
            Row(children: [
              Icon(Icons.location_on_outlined, color: Colors.white),
              SizedBox(width: 5),
              Text('الناصرية، ذي قار', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            ]),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('اختار التخصص', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: navy)),
        const SizedBox(height: 10),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: ['الكل', 'طب عام', 'أطفال', 'أسنان'].map((s) => Padding(
              padding: const EdgeInsets.only(left: 8),
              child: ChoiceChip(label: Text(s), selected: specialty == s, onSelected: (_) => setState(() => specialty = s)),
            )).toList(),
          ),
        ),
        const SizedBox(height: 12),
        const Text('أطباء مقترحون', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: navy)),
        const SizedBox(height: 8),
        ...filtered.map(_doctorCard),
        const SizedBox(height: 8),
        const Text('تنبيه: الأطباء والمواعيد الظاهرة بيانات تجريبية للتصميم وليست عيادات مؤكدة.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }

  Widget _doctorCard(DoctorDemo d) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(backgroundColor: const Color(0xFFE4F5F3), child: const Icon(Icons.medical_services_outlined, color: brand)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: navy)),
              Text('${d.specialty} • ${d.clinic}', style: const TextStyle(color: Colors.black54)),
            ])),
            const Icon(Icons.verified_outlined, color: brand),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            const Icon(Icons.location_on_outlined, size: 18, color: brand),
            const SizedBox(width: 4),
            Expanded(child: Text(d.area, style: const TextStyle(fontSize: 13))),
          ]),
          const SizedBox(height: 6),
          Row(children: [
            const Icon(Icons.schedule, size: 18, color: brand),
            const SizedBox(width: 4),
            Text(d.time, style: const TextStyle(fontSize: 13)),
            const Spacer(),
            Text(d.fee, style: const TextStyle(fontWeight: FontWeight.w800, color: brand)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ClinicLocationScreen(clinicName: d.clinic, address: d.area, latitude: d.lat, longitude: d.lng))),
              icon: const Icon(Icons.map_outlined), label: const Text('موقع العيادة'),
            )),
            const SizedBox(width: 8),
            Expanded(child: FilledButton.icon(
              onPressed: () => _showBooking(d),
              icon: const Icon(Icons.calendar_month), label: const Text('احجز موعد'),
            )),
          ]),
        ]),
      ),
    );
  }

  void _showBooking(DoctorDemo d) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 26),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('تأكيد موعد تجريبي', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(d.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            Text('${d.clinic} — ${d.area}'),
            Text('الوقت المقترح: ${d.time}'),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: FilledButton(
              onPressed: () {
                Navigator.pop(ctx);
                _toast('هذا نموذج تجريبي فقط. سنفعّل الحجز الحقيقي بعد ربط Supabase.');
                Navigator.push(context, MaterialPageRoute(builder: (_) => ClinicLocationScreen(clinicName: d.clinic, address: d.area, latitude: d.lat, longitude: d.lng)));
              },
              child: const Text('متابعة وعرض موقع العيادة'),
            )),
          ]),
        ),
      ),
    );
  }

  void _toast(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class DoctorDemo {
  final String name, specialty, clinic, area, fee, time;
  final double lat, lng;
  const DoctorDemo({required this.name, required this.specialty, required this.clinic, required this.area, required this.fee, required this.time, required this.lat, required this.lng});
}

class _InfoPage extends StatelessWidget {
  final IconData icon;
  final String title, text;
  const _InfoPage({required this.icon, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 60, color: brand),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, height: 1.5)),
      ]),
    ),
  );
}
