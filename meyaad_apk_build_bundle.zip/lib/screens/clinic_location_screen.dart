import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

const meyaadTeal = Color(0xFF087F8C);

class ClinicLocationScreen extends StatelessWidget {
  final String clinicName;
  final String address;
  final double latitude;
  final double longitude;

  const ClinicLocationScreen({
    super.key,
    required this.clinicName,
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  @override
  Widget build(BuildContext context) {
    final clinic = LatLng(latitude, longitude);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('موقع العيادة')),
        body: Column(children: [
          Expanded(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(target: clinic, zoom: 15.5),
              markers: {
                Marker(
                  markerId: const MarkerId('clinic'),
                  position: clinic,
                  infoWindow: InfoWindow(title: clinicName, snippet: address),
                ),
              },
              myLocationButtonEnabled: false,
              mapToolbarEnabled: false,
              zoomControlsEnabled: true,
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            color: Colors.white,
            child: SafeArea(
              top: false,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(clinicName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.location_on_outlined, color: meyaadTeal),
                  const SizedBox(width: 6),
                  Expanded(child: Text(address)),
                ]),
                const SizedBox(height: 8),
                Text('الإحداثيات: ${latitude.toStringAsFixed(5)}, ${longitude.toStringAsFixed(5)}',
                    style: const TextStyle(fontSize: 12, color: Colors.black54)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
