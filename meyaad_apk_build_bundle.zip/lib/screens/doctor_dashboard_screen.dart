import 'package:flutter/material.dart';

const doctorBrand = Color(0xFF087F8C);

class DoctorDashboardScreen extends StatelessWidget {
  const DoctorDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final patients = [
      ('#01', 'مريض تجريبي ١', 'بانتظار الدور'),
      ('#02', 'مريض تجريبي ٢', 'بانتظار الدور'),
      ('#03', 'مريض تجريبي ٣', 'قيد المعاينة'),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ميعاد | لوحة الطبيب')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: doctorBrand,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('أهلاً دكتور', style: TextStyle(color: Colors.white70)),
                SizedBox(height: 5),
                Text('إدارة المواعيد والدور', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('هذه شاشة استعراضية ببيانات غير حقيقية.', style: TextStyle(color: Colors.white)),
              ]),
            ),
            const SizedBox(height: 18),
            const Text('طابور اليوم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            ...patients.map((p) => Card(
              child: ListTile(
                leading: CircleAvatar(backgroundColor: const Color(0xFFE4F5F3), child: Text(p.$1, style: const TextStyle(color: doctorBrand, fontWeight: FontWeight.w900))),
                title: Text(p.$2),
                subtitle: Text(p.$3),
                trailing: const Icon(Icons.more_horiz),
              ),
            )),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تحديث الدور الحقيقي يحتاج ربط قاعدة البيانات والصلاحيات.')),
              ),
              icon: const Icon(Icons.campaign_outlined),
              label: const Text('إشعار المرضى بتحديث الدور'),
            ),
          ],
        ),
      ),
    );
  }
}
