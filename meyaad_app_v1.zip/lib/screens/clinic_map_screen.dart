import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../main.dart';

class ClinicMapScreen extends StatelessWidget {
  final DemoDoctor doctor;
  const ClinicMapScreen({super.key, required this.doctor});

  @override
  Widget build(BuildContext context) {
    final location = LatLng(doctor.latitude, doctor.longitude);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('موقع العيادة')),
        body: Column(children: [
          Expanded(child: GoogleMap(
            initialCameraPosition: CameraPosition(target: location, zoom: 15.5),
            markers: {
              Marker(markerId: const MarkerId('clinic'), position: location, infoWindow: InfoWindow(title: doctor.clinic, snippet: doctor.address)),
            },
            zoomControlsEnabled: true,
            myLocationButtonEnabled: false,
          )),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            color: Colors.white,
            child: SafeArea(top: false, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(doctor.clinic, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: meyaadNavy)),
              const SizedBox(height: 6),
              Row(children: [const Icon(Icons.location_on_outlined, color: meyaadTeal), const SizedBox(width: 6), Expanded(child: Text(doctor.address))]),
              const SizedBox(height: 6),
              const Text('الموقع والإحداثيات المعروضة تجريبية وليست عنوان عيادة حقيقية.', style: TextStyle(fontSize: 12, color: Colors.black54)),
            ])),
          ),
        ]),
      ),
    );
  }
}
