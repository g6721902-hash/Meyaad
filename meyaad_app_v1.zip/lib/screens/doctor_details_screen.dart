import 'package:flutter/material.dart';
import '../main.dart';

class DoctorDetailsScreen extends StatelessWidget {
  final DemoDoctor doctor;
  final VoidCallback onBooked;
  final VoidCallback onMap;
  const DoctorDetailsScreen({super.key, required this.doctor, required this.onBooked, required this.onMap});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الطبيب')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
          const CircleAvatar(radius: 38, backgroundColor: Color(0xFFE2F4F2), child: Icon(Icons.person, size: 45, color: meyaadTeal)),
          const SizedBox(height: 12),
          Text(doctor.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: meyaadNavy), textAlign: TextAlign.center),
          const SizedBox(height: 5),
          Text('اختصاص ${doctor.specialty}', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 8),
          Text('⭐ ${doctor.rating}  •  ${doctor.clinic}', style: const TextStyle(fontWeight: FontWeight.w700)),
        ]))),
        const SizedBox(height: 14),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.schedule, color: meyaadTeal), title: const Text('الموعد المتاح'), subtitle: Text(doctor.nextSlot)),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.payments_outlined, color: meyaadTeal), title: const Text('أجرة الكشف (تجريبية)'), subtitle: Text(doctor.fee)),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.location_on_outlined, color: meyaadTeal), title: const Text('عنوان العيادة'), subtitle: Text(doctor.address), trailing: IconButton(onPressed: onMap, icon: const Icon(Icons.map_outlined))),
        ])),
        const SizedBox(height: 14),
        const Text('عن العيادة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: meyaadNavy)),
        const SizedBox(height: 6),
        const Text('هذا محتوى تجريبي للتصميم. ستظهر تفاصيل الطبيب المعتمدة بعد التحقق من بياناته وموافقته على الانضمام إلى ميعاد.', style: TextStyle(height: 1.5, color: Colors.black54)),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: () => _confirm(context), icon: const Icon(Icons.calendar_month), label: const Text('احجز هذا الموعد'), style: FilledButton.styleFrom(padding: const EdgeInsets.all(15))),
      ]),
    ),
  );

  void _confirm(BuildContext context) {
    showDialog(context: context, builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('تأكيد الحجز التجريبي'),
        content: Text('تحب تحجز عند ${doctor.name}؟\\nالموعد: ${doctor.nextSlot}\\nالعيادة: ${doctor.address}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('رجوع')),
          FilledButton(onPressed: () { Navigator.pop(ctx); onBooked(); }, child: const Text('تأكيد')),
        ],
      ),
    ));
  }
}
