import 'package:flutter/material.dart';
import '../main.dart';
import 'clinic_map_screen.dart';

class QueueScreen extends StatelessWidget {
  final DemoDoctor doctor;
  const QueueScreen({super.key, required this.doctor});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('تأكيد الحجز')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: const Color(0xFFE4F5F3), borderRadius: BorderRadius.circular(24)),
          child: Column(children: [
            const Icon(Icons.check_circle_rounded, size: 48, color: meyaadTeal),
            const SizedBox(height: 8),
            const Text('تم تأكيد الحجز التجريبي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: meyaadNavy)),
            const SizedBox(height: 5),
            Text(doctor.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            Text('${doctor.clinic} • ${doctor.nextSlot}', textAlign: TextAlign.center),
            const SizedBox(height: 18),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
              child: const Column(children: [
                Text('رقم دورك التجريبي', style: TextStyle(color: Colors.black54)),
                SizedBox(height: 3),
                Text('12', style: TextStyle(fontSize: 54, fontWeight: FontWeight.w900, color: meyaadTeal)),
                Text('هذا الرقم للعرض فقط', style: TextStyle(fontSize: 11, color: Colors.black54)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 16),
        Card(child: const Column(children: [
          ListTile(leading: Icon(Icons.check_circle, color: meyaadTeal), title: Text('تم تسجيل الحجز (تجريبي)')),
          ListTile(leading: Icon(Icons.hourglass_top, color: Colors.orange), title: Text('بانتظار موعدك')),
          ListTile(leading: Icon(Icons.notifications_active_outlined, color: meyaadTeal), title: Text('الإشعارات المباشرة تُفعّل لاحقاً')),
        ])),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ClinicMapScreen(doctor: doctor))),
          icon: const Icon(Icons.location_on_outlined),
          label: const Text('عرض موقع العيادة على الخريطة'),
          style: FilledButton.styleFrom(padding: const EdgeInsets.all(15)),
        ),
      ]),
    ),
  );
}
