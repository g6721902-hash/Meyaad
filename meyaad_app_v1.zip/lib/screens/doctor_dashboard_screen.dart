import 'package:flutter/material.dart';
import '../main.dart';

class DoctorDashboardScreen extends StatefulWidget {
  const DoctorDashboardScreen({super.key});
  @override
  State<DoctorDashboardScreen> createState() => _DoctorDashboardScreenState();
}
class _DoctorDashboardScreenState extends State<DoctorDashboardScreen> {
  int currentNumber = 12;
  final patients = ['علي حسن', 'فاطمة محمد', 'حسين علي', 'نور أحمد', 'محمد باسم'];
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('ميعاد | لوحة الطبيب')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: meyaadTeal), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('أهلاً دكتور', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 4),
          const Text('إدارة المواعيد والدور', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Row(children: [
            const Expanded(child: Text('الدور الحالي', style: TextStyle(color: Colors.white))),
            Text('$currentNumber', style: const TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w900)),
          ]),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: currentNumber > 1 ? () => setState(() => currentNumber--) : null, style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70)), child: const Text('السابق'))),
            const SizedBox(width: 8),
            Expanded(child: FilledButton(onPressed: () => setState(() => currentNumber++), style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: meyaadTeal), child: const Text('التالي'))),
          ]),
        ])),
        const SizedBox(height: 18),
        const Text('قائمة المرضى (تجريبية)', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: meyaadNavy)),
        const SizedBox(height: 8),
        ...List.generate(patients.length, (i) => Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(backgroundColor: const Color(0xFFE4F5F3), child: Text('${i + 1}', style: const TextStyle(color: meyaadTeal, fontWeight: FontWeight.w900))),
            title: Text(patients[i]),
            subtitle: Text(i + 1 < currentNumber - 7 ? 'تم الكشف (تجريبي)' : 'بانتظار الدور'),
            trailing: const Icon(Icons.more_horiz),
          ),
        )),
        const SizedBox(height: 10),
        const Text('هذه اللوحة نموذج واجهة فقط؛ تحديث الدور لا يرسل إشعارات حقيقية قبل ربط الخادم.', style: TextStyle(color: Colors.black54, fontSize: 12)),
      ]),
    ),
  );
}
