from PIL import Image
from pathlib import Path
import re

icon = Image.open("assets/meyaad_icon.png").convert("RGBA")
sizes = {"mipmap-mdpi":48, "mipmap-hdpi":72, "mipmap-xhdpi":96,
         "mipmap-xxhdpi":144, "mipmap-xxxhdpi":192}
res = Path("android/app/src/main/res")
for folder, size in sizes.items():
    target = res / folder
    target.mkdir(parents=True, exist_ok=True)
    icon.resize((size, size), Image.Resampling.LANCZOS).save(target / "ic_launcher.png", optimize=True)

manifest = Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    data = manifest.read_text(encoding="utf-8")
    data = re.sub(r'android:label="[^"]*"', 'android:label="ميعاد"', data, count=1)
    data = re.sub(r'android:icon="@mipmap/[^"]+"', 'android:icon="@mipmap/ic_launcher"', data, count=1)
    manifest.write_text(data, encoding="utf-8")
print("Applied Arabic label and Meyaad icon.")
