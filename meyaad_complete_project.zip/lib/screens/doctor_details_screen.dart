import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../main.dart';

class DoctorDetailsScreen extends StatelessWidget {
  final DemoDoctor doctor;
  final VoidCallback onBooked;
  final VoidCallback onMap;
  const DoctorDetailsScreen({super.key, required this.doctor, required this.onBooked, required this.onMap});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الطبيب')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
          const CircleAvatar(radius: 38, backgroundColor: Color(0xFFE2F4F2), child: Icon(Icons.person, size: 45, color: meyaadTeal)),
          const SizedBox(height: 12),
          Text(doctor.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: meyaadNavy), textAlign: TextAlign.center),
          const SizedBox(height: 5),
          Text('اختصاص ${doctor.specialty}', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 8),
          Text('⭐ ${doctor.rating}  •  ${doctor.clinic}', style: const TextStyle(fontWeight: FontWeight.w700)),
        ]))),
        const SizedBox(height: 14),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.schedule, color: meyaadTeal), title: const Text('الموعد المتاح'), subtitle: Text(doctor.nextSlot)),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.payments_outlined, color: meyaadTeal), title: const Text('أجرة الكشف (تجريبية)'), subtitle: Text(doctor.fee)),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.location_on_outlined, color: meyaadTeal), title: const Text('عنوان العيادة'), subtitle: Text(doctor.address), trailing: IconButton(onPressed: onMap, icon: const Icon(Icons.map_outlined))),
        ])),
        const SizedBox(height: 14),
        const Text('عن العيادة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: meyaadNavy)),
        const SizedBox(height: 6),
        const Text('هذا محتوى تجريبي للتصميم. ستظهر تفاصيل الطبيب المعتمدة بعد التحقق من بياناته وموافقته على الانضمام إلى ميعاد.', style: TextStyle(height: 1.5, color: Colors.black54)),
        const SizedBox(height: 22),
        FilledButton.icon(
          onPressed: () => _contact(context, whatsapp: false),
          icon: const Icon(Icons.phone),
          label: const Text('اتصال هاتفي'),
          style: FilledButton.styleFrom(padding: const EdgeInsets.all(15)),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: () => _contact(context, whatsapp: true),
          icon: const Icon(Icons.chat),
          label: const Text('واتساب'),
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF168A58),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.all(15),
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'ملاحظة: بيانات الأطباء المعروضة حالياً تجريبية. أضف أرقاماً صحيحة بموافقة أصحابها قبل نشر التطبيق.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black54, fontSize: 12),
        ),
      ]),
    ),
  );

  Future<void> _contact(BuildContext context, {required bool whatsapp}) async {
    final phone = doctor.phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('رقم الطبيب غير مضاف بعد. أضف رقم العيادة الصحيح من بيانات الطبيب.'),
        ),
      );
      return;
    }
    final normalized = phone.startsWith('+') ? phone.substring(1) : phone;
    final uri = whatsapp
        ? Uri.parse('https://wa.me/$normalized')
        : Uri(scheme: 'tel', path: phone);
    try {
      final launched = await launchUrl(
        uri,
        mode: whatsapp ? LaunchMode.externalApplication : LaunchMode.platformDefault,
      );
      if (!launched && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر فتح التطبيق. تأكد من وجود تطبيق الهاتف أو واتساب.')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر فتح الرابط على هذا الجهاز.')),
        );
      }
    }
  }
}
