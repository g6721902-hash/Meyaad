import 'package:flutter/material.dart';
import '../main.dart';

class SearchScreen extends StatefulWidget {
  final List<DemoDoctor> doctors;
  final ValueChanged<DemoDoctor> onBook;
  const SearchScreen({super.key, required this.doctors, required this.onBook});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}
class _SearchScreenState extends State<SearchScreen> {
  final controller = TextEditingController();
  String specialty = 'الكل';
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final q = controller.text.trim();
    final list = widget.doctors.where((d) =>
      (specialty == 'الكل' || d.specialty == specialty) &&
      (q.isEmpty || d.name.contains(q) || d.specialty.contains(q) || d.clinic.contains(q))
    ).toList();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('البحث عن الأطباء', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: meyaadNavy)),
        const SizedBox(height: 12),
        TextField(
          controller: controller,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: 'اسم الطبيب أو التخصص أو العيادة',
            prefixIcon: const Icon(Icons.search, color: meyaadTeal),
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE3ECEE))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE3ECEE))),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 7,
          runSpacing: 6,
          children: ['الكل', 'باطنية', 'أطفال', 'أسنان', 'جلدية']
              .map((s) => ChoiceChip(
                    label: Text(s),
                    selected: specialty == s,
                    onSelected: (_) => setState(() => specialty = s),
                  ))
              .toList(),
        ),
        const SizedBox(height: 14),
        Text('النتائج: ${list.length}', style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 8),
        ...list.map((d) => Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            contentPadding: const EdgeInsets.all(12),
            leading: const CircleAvatar(backgroundColor: Color(0xFFE2F4F2), child: Icon(Icons.medical_services_outlined, color: meyaadTeal)),
            title: Text(d.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('${d.specialty} • ${d.clinic}\n${d.address}\nالتقييم ${d.rating} • ${d.fee}'),
            isThreeLine: true,
            trailing: const Icon(Icons.chevron_left),
            onTap: () => widget.onBook(d),
          ),
        )),
      ]),
    );
  }
}
