import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/clinic_map_screen.dart';
import 'screens/doctor_dashboard_screen.dart';
import 'screens/doctor_details_screen.dart';
import 'screens/queue_screen.dart';
import 'screens/search_screen.dart';

void main() => runApp(const MeyaadApp());

const Color meyaadTeal = Color(0xFF07858A);
const Color meyaadDarkTeal = Color(0xFF075D68);
const Color meyaadNavy = Color(0xFF183B4B);
const Color meyaadBg = Color(0xFFF3F8F9);

class MeyaadApp extends StatelessWidget {
  const MeyaadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ميعاد',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: meyaadTeal, primary: meyaadTeal),
        scaffoldBackgroundColor: meyaadBg,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: meyaadNavy,
          centerTitle: false,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE3ECEE)),
          ),
        ),
      ),
      home: const PatientShell(),
    );
  }
}

class PatientShell extends StatefulWidget {
  const PatientShell({super.key});

  @override
  State<PatientShell> createState() => _PatientShellState();
}

class _PatientShellState extends State<PatientShell> {
  int selectedIndex = 0;
  String specialty = 'الكل';

  final doctors = DemoDoctor.samples;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(),
      SearchScreen(doctors: doctors, onBook: _openDoctor),
      const _MyBookingsPage(),
      const _AccountPage(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(children: [
            _BrandMark(),
            SizedBox(width: 9),
            Text('ميعاد', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 22)),
          ]),
          actions: [
            IconButton(
              tooltip: 'الإشعارات',
              onPressed: () => _snack('ماكو إشعارات جديدة حالياً'),
              icon: const Icon(Icons.notifications_none_rounded),
            ),
            const SizedBox(width: 5),
          ],
        ),
        body: SafeArea(child: IndexedStack(index: selectedIndex, children: pages)),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (v) => setState(() => selectedIndex = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.search_rounded), selectedIcon: Icon(Icons.search_rounded), label: 'الأطباء'),
            NavigationDestination(icon: Icon(Icons.confirmation_number_outlined), selectedIcon: Icon(Icons.confirmation_number_rounded), label: 'حجوزاتي'),
            NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _homePage() {
    final filtered = specialty == 'الكل' ? doctors : doctors.where((d) => d.specialty == specialty).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(21),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
            gradient: const LinearGradient(
              colors: [meyaadTeal, meyaadDarkTeal],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('صحتك بموعد أسهل', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            const Text('احجز عند الطبيب وتابع دورك من موبايلك', style: TextStyle(color: Colors.white, height: 1.5)),
            const SizedBox(height: 16),
            Row(children: [
              const Icon(Icons.location_on_outlined, color: Colors.white),
              const SizedBox(width: 4),
              const Text('الناصرية، ذي قار', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(30)),
                child: const Text('نسخة تجريبية', style: TextStyle(color: Colors.white, fontSize: 11)),
              ),
            ]),
          ]),
        ),
        const SizedBox(height: 20),
        InkWell(
          onTap: () => setState(() => selectedIndex = 1),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE1EAED))),
            child: const Row(children: [
              Icon(Icons.search, color: meyaadTeal),
              SizedBox(width: 10),
              Expanded(child: Text('ابحث عن طبيب أو تخصص...', style: TextStyle(color: Colors.black54))),
              Icon(Icons.tune_rounded, color: meyaadTeal),
            ]),
          ),
        ),
        const SizedBox(height: 19),
        const Text('التخصصات الطبية', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: meyaadNavy)),
        const SizedBox(height: 11),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: ['الكل', 'باطنية', 'أطفال', 'أسنان', 'عيون', 'جلدية'].map((s) => ChoiceChip(
            label: Text(s),
            selected: specialty == s,
            onSelected: (_) => setState(() => specialty = s),
          )).toList(),
        ),
        const SizedBox(height: 20),
        Row(children: [
          const Expanded(child: Text('أطباء في الناصرية', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: meyaadNavy))),
          TextButton(onPressed: () => setState(() => selectedIndex = 1), child: const Text('عرض الكل')),
        ]),
        const SizedBox(height: 8),
        ...filtered.map((d) => _doctorCard(d)),
        const SizedBox(height: 16),
        const Text('ملاحظة: بيانات الأطباء والمواعيد تجريبية وليست عيادات مؤكدة.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }

  Widget _doctorCard(DemoDoctor d) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const CircleAvatar(radius: 25, backgroundColor: Color(0xFFE2F4F2), child: Icon(Icons.medical_services_outlined, color: meyaadTeal, size: 28)),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: meyaadNavy)),
              const SizedBox(height: 3),
              Text('${d.specialty} • ${d.clinic}', style: const TextStyle(color: Colors.black54, fontSize: 12)),
            ])),
            const Icon(Icons.verified_rounded, color: meyaadTeal),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            const Icon(Icons.location_on_outlined, size: 17, color: meyaadTeal),
            const SizedBox(width: 4),
            Expanded(child: Text(d.address, style: const TextStyle(fontSize: 12))),
          ]),
          const SizedBox(height: 7),
          Row(children: [
            const Icon(Icons.star_rounded, color: Color(0xFFF2B544), size: 19),
            Text(' ${d.rating}  •  ${d.nextSlot}', style: const TextStyle(fontSize: 12, color: Colors.black87)),
            const Spacer(),
            Text(d.fee, style: const TextStyle(color: meyaadTeal, fontWeight: FontWeight.w900)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () => _openMap(d),
              icon: const Icon(Icons.map_outlined),
              label: const Text('موقع العيادة'),
            )),
            const SizedBox(width: 8),
            Expanded(child: FilledButton.icon(
              onPressed: () => _openDoctor(d),
              icon: const Icon(Icons.calendar_month_rounded),
              label: const Text('احجز موعد'),
            )),
          ]),
        ]),
      ),
    ),
  );

  void _openDoctor(DemoDoctor d) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => DoctorDetailsScreen(doctor: d, onBooked: () {
      Navigator.push(context, MaterialPageRoute(builder: (_) => QueueScreen(doctor: d)));
    }, onMap: () => _openMap(d))));
  }

  void _openMap(DemoDoctor d) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ClinicMapScreen(doctor: d)));
  }

  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
}

class _BrandMark extends StatelessWidget {
  const _BrandMark();
  @override
  Widget build(BuildContext context) => Container(
    width: 34, height: 34,
    decoration: BoxDecoration(color: meyaadTeal, borderRadius: BorderRadius.circular(11)),
    child: const Icon(Icons.health_and_safety_outlined, color: Colors.white, size: 23),
  );
}

class DemoDoctor {
  final String name, specialty, clinic, address, fee, nextSlot, rating, phone;
  final double latitude, longitude;
  const DemoDoctor({required this.name, required this.specialty, required this.clinic, required this.address, required this.fee, required this.nextSlot, required this.rating, required this.latitude, required this.longitude, this.phone = ''});

  static const samples = [
    DemoDoctor(name: 'د. أحمد حسن الخفاجي', specialty: 'باطنية', clinic: 'عيادة النور', address: 'الناصرية، شارع الحبوبي', fee: '١٥٬٠٠٠ د.ع', nextSlot: 'اليوم ٥:٣٠ م', rating: '4.9', latitude: 31.0575, longitude: 46.2573),
    DemoDoctor(name: 'د. سارة علي', specialty: 'أطفال', clinic: 'عيادة الرحمة', address: 'الناصرية، صوب الشامية', fee: '٢٠٬٠٠٠ د.ع', nextSlot: 'اليوم ٦:٠٠ م', rating: '4.8', latitude: 31.0458, longitude: 46.2591),
    DemoDoctor(name: 'د. علي ناصر', specialty: 'أسنان', clinic: 'مركز الابتسامة', address: 'الناصرية، شارع النيل', fee: '٢٥٬٠٠٠ د.ع', nextSlot: 'غداً ٤:٠٠ م', rating: '4.7', latitude: 31.0521, longitude: 46.2654),
    DemoDoctor(name: 'د. مروة عبد الله', specialty: 'جلدية', clinic: 'مركز الشفاء', address: 'الناصرية، حي الإدارة', fee: '٢٠٬٠٠٠ د.ع', nextSlot: 'غداً ٥:٠٠ م', rating: '4.9', latitude: 31.0610, longitude: 46.2505),
  ];
}

class _MyBookingsPage extends StatelessWidget {
  const _MyBookingsPage();
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('حجوزاتي', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: meyaadNavy)),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        const Icon(Icons.event_available_outlined, size: 48, color: meyaadTeal),
        const SizedBox(height: 8),
        const Text('ما عندك حجوزات محفوظة بعد', style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        const Text('اختار طبيب من الصفحة الرئيسية حتى تبدأ حجزك التجريبي.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
      ]))),
    ]),
  );
}

class _AccountPage extends StatelessWidget {
  const _AccountPage();
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('حسابي', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: meyaadNavy)),
      const SizedBox(height: 12),
      const Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person_outline)), title: Text('حساب المريض'), subtitle: Text('تسجيل الدخول برقم الهاتف سيُفعّل لاحقاً'))),
      const SizedBox(height: 10),
      Card(
        child: ListTile(
          leading: const Icon(Icons.medical_services_outlined, color: meyaadTeal),
          title: const Text('معاينة واجهة الطبيب'),
          subtitle: const Text('نموذج تجريبي لإدارة الدور'),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const DoctorDashboardScreen()),
          ),
        ),
      ),
    ]),
  );
}
